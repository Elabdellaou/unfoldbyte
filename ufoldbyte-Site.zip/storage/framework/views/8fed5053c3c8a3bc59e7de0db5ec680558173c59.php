<section class="vh-100 position-relative footer d-flex justify-content-center align-items-center content-picture">
    <svg width="1374" height="501" viewBox="0 0 1374 501" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M21.4116 92.4597L165.411 105.349L165.576 105.364L165.737 105.325L308.234 70.5412L308.237 70.5404L597.474 1.03473L907.718 92.3334L907.958 92.4041L908.203 92.3533L1243.71 22.8872L1372.96 139.542L1352.06 350.286L1077.87 474.004L704.669 410.014L704.477 409.981L704.287 410.023L410.851 474.05L100.539 499.952L1.02358 333.072L21.4116 92.4597Z" stroke="#E4FF67" stroke-width="2"/>
    </svg>
    <div class="w-100 position-absolute start-50 top-50 translate-middle">
        <div class="w-100 d-flex flex-column justify-content-center align-items-center">
            <a href="#" class="p-small cursor-big text-decoration-none text-white mb-5">Next Product</a>
            <h1 class="p-big-footer cursor-big mt-5">ProAccounter</h1>
            <span class="p-small cursor-big mb-5">Account application</span>
        </div>
    </div>
</section>
<?php /**PATH C:\xampp\htdocs\ufoldbyte-Site\resources\views/includes/footer.blade.php ENDPATH**/ ?>