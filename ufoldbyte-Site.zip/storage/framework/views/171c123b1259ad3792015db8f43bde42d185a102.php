<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('includes.loading', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('includes.header_p', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <main id="project-page" class="text-white">
        <section class="container-lg d-flex flex-column align-items-center">
            <div class="mb-5 w-100 row row-cols-1 row-cols-lg-2">
                <div class="mb-5">
                    <h1 class="title cursor-big">Drive</h1>
                    <span class="p-small pa-1 cursor-big">Car rental management</span>
                </div>
                <div class="row row-cols-2 mb-5">
                    <span class="cursor-big p-small pj">
                        Year <br>
                        <span class="p-m">2022</span>
                    </span>
                    <span class="cursor-big p-small pj">
                        Role <br>
                        <span class="p-m">Dev & design</span>
                    </span>
                    <span class="cursor-big mt-5 p-small pj">
                        Client <br>
                        <span class="p-m">To agence</span>
                    </span>
                    <span class="cursor-big mt-5 p-small pj">
                        Product type <br>
                        <span class="p-m">Desktop</span>
                    </span>
                    <div>
                        <button class="btn-outline-unfold cursor-big rounded-pill text-white mt-5" id="view-website"
                            data-product="Drive">VIEW WEBSITE</button>
                    </div>
                </div>
            </div>
            <section class="content-picture img-1 my-5 d-flex align-items-center">
                <img src="/images/project1.png" class=" cursor-big" alt="" srcset="">
            </section>
            <section class="row row-cols-1 row-cols-lg-2">
                <p class="pj-1 text-start my-5">
                    <span class="d-flex align-items-center flex-row">
                        <span class="p-small pe-4 cursor-big">OVERVIEW</span>
                        <span class="cursor-big p-big">
                            SOFTWARE MAKES
                        </span>
                    </span>
                    <span class="cursor-big p-big">
                        EVERYTHING EASY.
                    </span>
                </p>
                <p class="p-small pa-3 text-start my-5 cursor-big">
                    In a culture where men turn to barbers to achieve the smoothest shave, or to a hairstylist for styling instead of just a cut, it was clear to sought-after men’s grooming expert, Vaughn Acord, that it was time to create a range of men’s products tailored to their needs.
                </p>
            </section>
            <section class="vh-100 row row-cols-1 row-cols-lg-2">
                <div class="h-100 content-picture d-flex align-items-center">
                    <img class="w-100 pe-5 cursor-big" src="/images/project3.png" alt="" srcset="">
                </div>
                <div class="d-flex align-items-center">
                    <div style="height: fit-content">
                        <span class="p-big cursor-big mb-5">SOMETHING COOL</span>
                        <br>
                        <span class="p-small cursor-big">
                            In a culture where men turn to barbers to achieve the smoothest shave, or to a hairstylist for styling instead of just a cut, it was clear to sought-after men’s grooming expert, Vaughn Acord, that it was time to create a range of men’s products tailored to their needs.
                        </span>
                    </div>
                </div>
            </section>
            <section class="vh-100 row row-cols-1 row-cols-lg-2">
                <div class="h-100 content-picture d-flex align-items-center">
                    <img class="w-100 pe-5 cursor-big" src="/images/project3.png" alt="" srcset="">
                </div>
                <div class="d-flex align-items-center">
                    <div style="height: fit-content">
                        <span class="p-big cursor-big mb-5">SOMETHING COOL</span>
                        <br>
                        <span class="p-small cursor-big">
                            In a culture where men turn to barbers to achieve the smoothest shave, or to a hairstylist for styling instead of just a cut, it was clear to sought-after men’s grooming expert, Vaughn Acord, that it was time to create a range of men’s products tailored to their needs.
                        </span>
                    </div>
                </div>
            </section>
            <section class="vh-100 content-picture img-1 my-5 d-flex align-items-center">
                <img src="/images/project4.png" class=" cursor-big" alt="" srcset="">
            </section>
            <section class="vh-100 row row-cols-1 row-cols-lg-2">
                <div class="h-100 content-picture d-flex align-items-center">
                    <img class="w-100 pe-5 cursor-big" src="/images/project3.png" alt="" srcset="">
                </div>
                <div class="d-flex align-items-center">
                    <div style="height: fit-content">
                        <span class="p-big cursor-big mb-5">SOMETHING COOL</span>
                        <br>
                        <span class="p-small cursor-big">
                            In a culture where men turn to barbers to achieve the smoothest shave, or to a hairstylist for styling instead of just a cut, it was clear to sought-after men’s grooming expert, Vaughn Acord, that it was time to create a range of men’s products tailored to their needs.
                        </span>
                    </div>
                </div>
            </section>
            <section class="w-100 position-relative">
                <div class="vh-100 w-75 content-picture">
                    <img class="w-100 cursor-big" src="/images/p6.png" alt="" srcset="">
                </div>
                <div class="row row-cols-2">
                    <p class="pj-4 text-start my-5">
                        <span class="d-flex align-items-center flex-row">
                            <span class="p-small pe-4 cursor-big">OUTCOME</span>
                            <span class="cursor-big p-big">
                                SOFTWARE MAKES
                            </span>
                        </span>
                        <span class="cursor-big p-big">
                            EVERYTHING EASY.
                        </span>
                    </p>
                    <div class="content-picture vh-100 position-absolute start-100" style="max-width: 40%;top:40%;width: 40%;">
                        <img class="pe-5 w-100 h-100 cursor-big" src="/images/project5.png" alt="" srcset="">
                    </div>
                </div>
            </section>
            <section
                class="vh-100 position-relative footer d-flex justify-content-center align-items-center content-picture">
                <svg width="1374" height="501" viewBox="0 0 1374 501" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path
                        d="M21.4116 92.4597L165.411 105.349L165.576 105.364L165.737 105.325L308.234 70.5412L308.237 70.5404L597.474 1.03473L907.718 92.3334L907.958 92.4041L908.203 92.3533L1243.71 22.8872L1372.96 139.542L1352.06 350.286L1077.87 474.004L704.669 410.014L704.477 409.981L704.287 410.023L410.851 474.05L100.539 499.952L1.02358 333.072L21.4116 92.4597Z"
                        stroke="#E4FF67" stroke-width="2" />
                </svg>
                <div class="w-100 position-absolute start-50 top-50 translate-middle">
                    <div class="w-100 d-flex flex-column justify-content-center align-items-center">
                        <a href="#" class="p-small cursor-big text-decoration-none text-white mb-5">Next Product</a>
                        <h1 class="p-big-footer cursor-big mt-5">ProAccounter</h1>
                        <span class="p-small cursor-big mb-5">Account application</span>
                    </div>
                </div>
            </section>
        </section>
    </main>
    <span id="cursor"></span>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ufoldbyte-Site\resources\views/project/drive.blade.php ENDPATH**/ ?>